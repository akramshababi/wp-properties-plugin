<?php get_header(); ?>
  <div class="py-5">
    <div class="container">
      <div class="row hidden-md-up">
        <?php if(have_posts()) {
            while(have_posts()) {
                the_post(); ?>
        <div class="col-md-4">
          <div class="card py-3 my-3">
            <div class="card-block px-3">
              <a href="<?php echo esc_url(get_the_permalink()); ?>"><img class="card-img-top img-thumbnail featured-image" src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="Property Image" style="width:100%; height:250px"></a>
              <h4 class="card-title my-3"><a href="<?php echo esc_url(get_the_permalink()); ?>"><?php the_title(); ?></a></h4>
              <p class="card-text p-y-1"><?php the_excerpt(); ?></p>
              <a href="<?php echo esc_url(get_the_permalink()); ?>" class="btn btn-primary">Read more</a>
            </div>
          </div>
        </div>
            <?php }
        } ?>
      </div>
    </div>
  </div>
<?php get_footer(); ?>



