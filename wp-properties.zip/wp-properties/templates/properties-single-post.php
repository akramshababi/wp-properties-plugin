<?php get_header(); ?>
    <div class="container my-5">
        <div class="my-5"><?php the_post_thumbnail(); ?></div>
        <h3><?php the_title(); ?></h3>
        <p><?php the_content(); ?></p>
    </div>
<?php get_footer(); ?>



