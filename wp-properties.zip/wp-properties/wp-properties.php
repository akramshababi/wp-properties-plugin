<?php
/**
 * Plugin Name:       WP Properties
 * Plugin URI:        https://wpgeniustuts.com/
 * Description:       Build full Real Estate website with this plugin
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Akram Shababi
 * Author URI:        https://wpgeniustuts.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://wpgeniustuts.com/
 * Text Domain:       wp-properties
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) {
     exit; 
    }

//Register and enqueue CSS styles
function wp_properties_plugin_scripts() {
        wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css', 'bootstrap', 'all');
        wp_enqueue_style('wp-properties-styles', dirname( __FILE__ ) . '/assets/css/style.css' );
}
add_action('wp_enqueue_scripts', 'wp_properties_plugin_scripts');

//Register the Properties custom post type
function register_wp_properties_post_type() {
    register_post_type('properties',
        array(
            'labels'      => array(
                'name'          => __('Properties', 'wp-properties'),
                'singular_name' => __('Property', 'wp-properties'),
            ),
                'public'        => true,
                'has_archive'   => true,
                'hierarchical'  => true,
                'publicly_queryable' => true,
                'supports'      => array( 'title', 'editor', 'thumbnail' ),
        )
    );
}

add_action('init', 'register_wp_properties_post_type');

//Register the properties categories
function wp_properties_register_taxonomy_property() {
    $labels = array(
        'name'              => _x( 'Property Categories', 'taxonomy general name' ),
        'singular_name'     => _x( 'Property Category', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Property Categories' ),
        'all_items'         => __( 'All Property Categories' ),
        'parent_item'       => __( 'Parent Property Category' ),
        'parent_item_colon' => __( 'Property Category:' ),
        'edit_item'         => __( 'Edit Property Category' ),
        'update_item'       => __( 'Update Property Category' ),
        'add_new_item'      => __( 'Add New Property Category' ),
        'new_item_name'     => __( 'New Property Category Name' ),
        'menu_name'         => __( 'Property Categories' ),
    );
    $args   = array(
        'hierarchical'      => true, // make it hierarchical (like categories)
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
    );
    register_taxonomy( 'property_category', [ 'properties' ], $args );
}
add_action( 'init', 'wp_properties_register_taxonomy_property' );

//Create and specify the peoperties archive template
add_filter( 'archive_template', 'wp_properties_custom_post_type_archive_template' );
function wp_properties_custom_post_type_archive_template($archive_template) {
     global $post;

     if ($post->post_type == 'properties' ) {
          $archive_template = dirname( __FILE__ ) . '/templates/properties-archive.php';
     }
     return $archive_template; 
}

//Create and specify the properties single post template
add_filter( 'single_template', 'wp_properties_custom_post_type_single_template' );
function wp_properties_custom_post_type_single_template($single_template) {
     global $post;

     if ($post->post_type == 'properties' ) {
          $single_template = dirname( __FILE__ ) . '/templates/properties-single-post.php';
     }
     return $single_template;  
}

//Add the properties manager role
    function wp_properties_manager() {
        add_role(
            'properties_manager',
            'Properties Manager',
            array(
                'read'         => true,
                'edit_posts'   => true,
                'upload_files' => true,
            ),
        );
    }
     
add_action( 'init', 'wp_properties_manager' );

//Add the adminstration sub menu for WP Properties plugin shortcodes section
function wp_properties_shortcodes_html() {
    ?><h1>Your properties Shortcodes</h1>
    <p>In this section you can find the plugin shortcodes (soon)</p>
<?php }

function add_properties_shortcodes_sub_menu() {
    add_submenu_page(
        'edit.php?post_type=properties',
        'Properties Shortcodes',
        'Properties Shortcodes',
        'manage_options',
        'properties-shortcodes',
        'wp_properties_shortcodes_html'
    );
}
add_action('admin_menu', 'add_properties_shortcodes_sub_menu');

//Specify the exerpt length for property custom post type
function wp_properties_excerpt_length($length) {
    global $post;
        if ($post->post_type == 'properties') {
            return 10;
    }}
add_filter('excerpt_length', 'wp_properties_excerpt_length', 100);